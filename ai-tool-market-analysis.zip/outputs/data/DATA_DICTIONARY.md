# Data Dictionary

Complete reference for all columns in AI_Tools_Market_Analysis.xlsx

---

## Tool Overview Sheet

### Column Definitions

| Column | Data Type | Description | Source | Notes |
|--------|-----------|-------------|--------|-------|
| Tool Name | Text | Official product name | Company website | Standardized names (e.g., "ChatGPT" not "Chat GPT") |
| Company | Text | Parent company name | Company website | E.g., "OpenAI" for ChatGPT, "Anthropic" for Claude |
| Launch Year | Number | Year tool was publicly released | Company history / press releases | ChatGPT: 2022, Claude: 2023 |
| Primary Use Case | Text | Main intended use (can be multiple) | Product marketing, documentation | E.g., "Code generation, developer productivity" |
| Target Users | Text | Primary customer segments | Sales/marketing materials | E.g., "Individual developers, teams, enterprise" |
| Free Tier? | Text | Whether free access tier exists | Pricing page | "Yes", "No", "Partial" (e.g., limited tokens/month) |

---

## Pricing Comparison Sheet

### Column Definitions

| Column | Data Type | Description | Source | Notes |
|--------|-----------|-------------|--------|-------|
| Tool | Text | Product name (matches Tool Overview) | Tool Overview sheet | Foreign key for cross-referencing |
| Free Tier | Text | Name/description of free offering | Pricing page | Includes limitations (e.g., "Limited to GPT-3.5") |
| Starter/Pro | Text | Name of entry-level paid tier | Pricing page | Often called "Pro", "Starter", or "Premium" |
| Starter Price | Currency USD | Monthly subscription cost | Pricing page | If plan doesn't exist, left blank |
| Professional | Text | Name of mid-level paid tier | Pricing page | Often called "Professional", "Team", "Business" |
| Pro Price | Currency USD | Monthly cost for professional tier | Pricing page | Includes standard features for 1-10 person team |
| Enterprise | Text | Name of enterprise tier | Pricing page | Usually "Enterprise", "Contact Sales", "Custom" |
| Ent. Price | Currency USD | Enterprise tier pricing | Pricing page or sales docs | Often "Custom" or negotiated; listed if published |
| Annual Discount % | Percentage | Discount for annual vs. monthly billing | Pricing page | E.g., "10%" means annual costs 90% of monthly×12 |

### Pricing Notes

- **ChatGPT:** $20/mo Pro (includes GPT-4), $30/mo Team (1-30 person teams)
- **Claude:** $20/mo Pro (includes Claude 3 family), API pricing varies by model
- **Copilot:** $20/mo individual, $39/mo business (per seat)
- **Cohere:** Freemium API model, no fixed seat-based pricing
- **Together AI:** Pay-as-you-go API, no seat licenses
- **Amazon Q:** Bundled into AWS (no separate SKU)
- **Grok:** Accessed via X Premium ($168/mo bundle, not standalone)

---

## Features Matrix Sheet

### Column Definitions

All rows represent **capabilities**; columns represent **tools**.

| Feature | Scale | Description | Scoring Method | Examples |
|---------|-------|-------------|-----------------|----------|
| Text Generation | 0-5 | Core ability to generate human-like text | Documentation + testing | All tools score 5; baseline capability |
| Code Generation | 0-5 | Ability to write, complete, debug code | Documentation + testing | Claude: 5, ChatGPT: 4, Perplexity: 3 |
| Image Generation | 0-5 | Can create images from text description | Feature availability | ChatGPT: 5, Gemini: 5, others: 0 |
| Multi-modal (Image Input) | 0-5 | Accepts images as input, not just text | Feature availability | Claude: 3 (limited), ChatGPT: 5, Copilot: 0 |
| Web Search/Real-time Info | 0-5 | Can search web or access current data | Feature availability | Perplexity: 5, Grok: 5, Claude: 0 |
| Long Context Window | 0-5 | Max token context (higher = better) | Specification (tokens/1000) | Claude: 5 (200K), ChatGPT: 3 (128K), Copilot: 2 (8K) |
| Fine-tuning Available | 0-5 | Can customize model on your data | Feature availability | Cohere: 5, ChatGPT: 4, Claude: 2 |
| API Available | 0-5 | Can integrate via API (not just chat) | Feature availability | All major tools: 5, some niche: 0 |
| Custom Deployment | 0-5 | Can run on-premise or private cloud | Deployment options | Cohere: 5 (full control), Together: 5, OpenAI: 2 |
| Reasoning/CoT | 0-5 | Chain-of-thought / step-by-step reasoning | Model capability | Claude: 5, ChatGPT: 4, Perplexity: 4 |
| Open Source Option | 0-5 | Can access or deploy open-source version | Availability | Together: 5 (Llama models), most commercial: 0 |
| Safety/Alignment Focus | 0-5 | Emphasis on safe, aligned behavior | Company positioning | Claude: 5 (explicit focus), ChatGPT: 4, Grok: 2 |

### Scoring Scale

- **5 = Fully Implemented:** Mature, competitive advantage in this area
- **4 = Implemented:** Competitive, meets market standard
- **3 = Partial:** Limited implementation or clear roadmap
- **2 = Limited:** Minimal capability
- **0 = Not Available:** Feature does not exist in product

### Validation Notes

- Scores are based on June 2026 product state
- Scores are **subjective**; recommend hands-on testing for validation
- A score of 5 does not mean "best in class"—compare across rows to identify leaders
- Rapidly evolving space; scores will be outdated in 3-6 months

---

## Review Data Sheet

### Column Definitions

| Column | Data Type | Description | Source | Notes |
|--------|-----------|-------------|--------|-------|
| Tool | Text | Product name (matches Tool Overview) | G2.com profile | Foreign key |
| G2 Rating (5.0) | Number (0-5) | Overall satisfaction score | G2.com | Decimal to 0.1 (e.g., 4.7★) |
| Total Reviews | Number | Count of verified customer reviews | G2.com | As of June 2026; includes paid + free tier users |
| Ease of Use | Number (0-5) | User-reported onboarding/UX quality | G2.com review breakdown | Calculated as avg of ease-of-use ratings |
| Feature Richness | Number (0-5) | Users' perception of feature completeness | G2.com review breakdown | Calculated as avg of feature reviews |
| Customer Support | Number (0-5) | Quality/responsiveness of support | G2.com review breakdown | Calculated as avg of support quality ratings |
| Sentiment | Text | Qualitative sentiment across reviews | G2.com review sampling | "Very Positive", "Positive", "Mixed", "Negative" |

### Data Quality Notes

- **Sample Size:** Claude (3.2K), ChatGPT (8.5K), Copilot (5.2K) = large, statistically significant samples
- **Small Samples:** Grok (650), Amazon Q (320), Together (420) = smaller confidence intervals; interpret cautiously
- **Recency Bias:** G2 reviews weighted toward recent (last 12 months), reducing outdated feedback
- **Source Bias:** G2 primarily English-language, US/EU weighted; global perspective limited

### Interpretation Guide

| Rating | Meaning |
|--------|---------|
| 4.6-5.0 | Excellent customer satisfaction, strong competitive position |
| 4.3-4.5 | Good satisfaction, competitive, minor improvement areas |
| 4.0-4.2 | Acceptable, some satisfaction gaps |
| <4.0 | Lower satisfaction, notable customer concerns |

---

## Segment Analysis Setup Sheet

### Customer Segments

| Segment | Definition | Annual Spend | Team Size | Use Case |
|---------|-----------|--------------|-----------|----------|
| Solo Developer | 1 person, freelancer/indie | $240 | 1 | Code completion, debugging, writing documentation |
| Small Startup | 5-15 person team | $6,000 | 10 | Content automation, code generation, process optimization |
| Mid-Market | 50-500 person company | $60,000 | 100 | Distributed team coordination, analysis automation, customer service |
| Enterprise | 1000+ person organization | $600,000 | 1000 | Governance, compliance, integration into core workflows |

### ROI Calculation Columns

| Metric | Formula | Interpretation |
|--------|---------|-----------------|
| Hours/week saved by tool | User input (editable) | Varies by tool and use case; recommend validating with customer interviews |
| Avg hourly rate | User input (editable) | Blended rate for segment (salary + benefits ÷ 2000 hours/year) |
| Annual work hours saved value | Hours/week × Rate × 52 weeks | Total economic value created by tool |
| Tool cost (annual) | Monthly spend × 12 × (1 - annual discount) | Annual subscription cost |
| Simple ROI Multiple | Value ÷ Cost | "X times return" (e.g., 32x means $1 spent = $32 value) |

### Assumptions Documentation

**Solo Developer ($240/year, 5 hours/week saved):**
- Uses tool for code generation and documentation
- Hourly rate: $50 (freelancer market rate)
- Annual value: 5 × $50 × 52 = $13,000
- ROI multiple: $13,000 ÷ $240 = 54x

**Small Startup ($6,000/year, 50 hours/week saved):**
- Tool used across 10-person team
- Hourly rate: $75 (blend of PM, engineer, content roles)
- Annual value: 50 × $75 × 52 = $195,000
- ROI multiple: $195,000 ÷ $6,000 = 32x

**Mid-Market ($60,000/year, 200 hours/week saved):**
- Distributed team, multiple use cases
- Hourly rate: $100 (average employee fully-loaded cost)
- Annual value: 200 × $100 × 52 = $1,040,000
- ROI multiple: $1,040,000 ÷ $60,000 = 17x

**Enterprise ($600,000/year, 500 hours/week saved):**
- Large organization, governance overhead
- Hourly rate: $120 (higher-paid workforce)
- Annual value: 500 × $120 × 52 = $3,120,000
- ROI multiple: $3,120,000 ÷ $600,000 = 5x

**⚠️ Important:** These are **directional estimates**, not prescriptive. Actual hours saved vary by:
- Industry (financial services may save 10x more than manufacturing)
- Role (developers benefit differently than sales teams)
- Use case (code generation vs. writing vs. analysis)

Recommend validating with customer interviews before using in proposals.

---

## Analysis Dashboard Sheet

### Derived Metrics

All metrics in this sheet are **calculated from other sheets**—not primary data.

| Metric | Formula Source | Interpretation |
|--------|-----------------|-----------------|
| Average G2 Rating | Average of G2 Rating column | Overall market satisfaction (weighted by review count) |
| Total Reviews | Sum of total reviews | Market penetration proxy (more reviews = more users) |
| Tools with Free Tier | Count of "Yes" in Free Tier column | Market accessibility metric |
| Avg Professional Price | Average of Professional pricing column | Mid-market pricing benchmark |
| Value Ratio (Features/$) | Avg Feature Score ÷ Professional Price | Indicates relative value; higher is better |
| ROI Multiple by Segment | Derived from Segment Analysis | Shows payback attractiveness |

---

## Accuracy & Validation

### High Confidence (±5% uncertainty)
- ✅ Pricing data (public, verifiable)
- ✅ G2 ratings (large sample, published)
- ✅ Feature existence (documented capabilities)

### Medium Confidence (±15% uncertainty)
- ⚠️ Feature scores (subjective evaluation)
- ⚠️ Customer satisfaction dimensions (smaller sample per metric)
- ⚠️ Hours saved (industry estimates)

### Lower Confidence (±30%+ uncertainty)
- ⚠️ TAM estimates (top-down calculation)
- ⚠️ Market share projections (interpolated)
- ⚠️ Future pricing (subject to change)

---

## Data Refresh Recommendations

| Data Type | Frequency | Method |
|-----------|-----------|--------|
| Pricing | Monthly | Check official pricing pages, set calendar reminder |
| Features | Quarterly | Review product release notes, validate with hands-on testing |
| Customer Satisfaction | Quarterly | Pull G2.com latest ratings (some tools update weekly) |
| ROI Assumptions | Annual | Validate with customer interviews, update if market conditions shift |
| Market Data | Annual | Compare with analyst reports (Gartner, Forrester) |

---

## Questions & Support

For data questions:
1. Check this data dictionary (you're reading it!)
2. See METHODOLOGY.md for sourcing details
3. See main README.md for project overview
4. Review the Excel file "Data Dictionary" sheet for formula documentation
