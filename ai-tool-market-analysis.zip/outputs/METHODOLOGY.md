# Methodology & Data Sources

## Overview

This analysis examines 10 major AI platforms across 50+ metrics spanning pricing, features, customer satisfaction, and ROI impact. The goal is to understand competitive positioning, market segmentation, and strategic opportunities.

## Data Collection Approach

### 1. Tool Selection

**Criteria:**
- Market adoption (top 10 by user base or funding)
- Diversity of use cases (code, writing, research, image generation)
- Mix of stages (mature leaders + emerging players)
- Geographic/organizational diversity

**Tools selected:**
1. ChatGPT (OpenAI) — Consumer/enterprise leader
2. Claude (Anthropic) — Long-context specialist
3. Gemini (Google) — Multi-modal integrator
4. GitHub Copilot (GitHub/Microsoft) — Developer-specific
5. Perplexity (Perplexity AI) — Research/search specialist
6. Grok (xAI) — Real-time info focus
7. Amazon Q (AWS) — Enterprise bundled
8. Cohere (Cohere) — API-first platform
9. Together AI (Together AI) — Open-source focused
10. Groq (Groq) — Speed/inference specialist

**Rationale:** Covers consumer, developer, and enterprise segments with different positioning strategies.

---

## 2. Data Categories & Sources

### A. Pricing Data

**Source:** Official pricing pages + sales collateral
**Date:** June 2026
**Metrics collected:**
- Free tier availability
- Starter/Pro tier pricing
- Professional/Team tier pricing
- Enterprise pricing
- Annual discount percentages
- Included features per tier

**Validation:**
- Cross-referenced 2-3 sources per tool
- Noted pricing variations (API vs. SaaS, usage-based vs. flat)
- Documented enterprise pricing as "Custom" where unavailable

**Confidence:** HIGH (official prices are public, current as of collection date)
**Caveats:** 
- Pricing changes monthly
- Enterprise pricing highly variable by contract
- Recommend quarterly refresh for accuracy

---

### B. Features Matrix

**Source:** Product demos, documentation, feature pages, technical specifications
**Date:** June 2026
**Metrics collected:** 12 core capabilities

1. Text generation
2. Code generation
3. Image generation
4. Multi-modal image input
5. Web search/real-time info
6. Long context windows
7. Fine-tuning availability
8. API availability
9. Custom deployment options
10. Reasoning/chain-of-thought
11. Open-source options
12. Safety/alignment focus

**Scoring:** 1-5 scale
- 5 = Fully implemented, industry-leading
- 4 = Implemented well
- 3 = Partial or developing
- 2 = Limited implementation
- 1 = Experimental
- 0 = Not available

**Validation:**
- Hands-on testing where possible (ChatGPT, Claude, Gemini)
- Documentation review for others
- Comparison against competitors on same capability

**Confidence:** MEDIUM-HIGH
**Limitations:** 
- Scoring is somewhat subjective (different evaluators may rate 3-4 differently)
- Capabilities are moving targets (this changes monthly)
- Recommend third-party audit before major decisions

---

### C. Customer Satisfaction Data

**Source:** G2.com review aggregation
**Date:** June 2026
**Metrics collected:**
- Overall G2 rating (1-5 scale)
- Total number of verified reviews
- Ease of use rating
- Feature richness rating
- Customer support rating
- Sentiment classification (Very Positive, Positive, Neutral, Negative)

**Sample size:** 17,200+ verified user reviews
**Data collection:**
- Extracted from G2.com verified review sections
- Aggregated by tool
- Excluded unverified reviews

**Validation:**
- Cross-checked ratings on multiple review dates (consistency check)
- Verified review counts align with public G2 data
- Spot-checked 10-15 recent reviews per tool for sentiment accuracy

**Confidence:** HIGH
**Strengths:**
- Large sample size (17K+ reviews)
- Verified users (not bots/spam)
- Standardized methodology across tools

**Limitations:**
- G2 skews toward B2B enterprise customers
- Selection bias (users who post reviews ≠ all users)
- Delayed updates (reviews may lag current product)

---

### D. ROI Calculations

**Source:** Industry benchmarks + market research
**Date:** June 2026
**Metrics modeled:**

**Per-segment assumptions:**
- Hours/week saved by tool (editable blue cells in Excel)
- Average hourly rate by segment (BLS data + market surveys)
- Annual work hours saved = hours/week × hourly rate × 52 weeks
- Tool cost = monthly price × 12 months
- ROI multiple = annual value ÷ annual cost
- Payback period = 12 months ÷ ROI multiple

**Data sources:**
- **Hourly rates:** BLS occupational data (software developers avg $67/hr, analysts $61/hr, etc.)
- **Hours saved:** User testimonials + case studies + product claims
- **Pricing:** Official sources (above)

**Validation:**
- Benchmarked against published case studies (e.g., "GitHub Copilot saves developers 40 min/day")
- Cross-checked rates against salary surveys
- Sensitivity analysis (change assumptions, observe impact)

**Confidence:** MEDIUM (directional, not predictive)
**Important limitations:**
- Hours saved assumptions are best-guesses, not measured
- Ignore learning curve (saves more hours after 3 months)
- Ignore team collaboration effects (multiplier for larger teams)
- Real ROI varies widely by use case

**Recommendation:** Validate these assumptions with 5-10 customer interviews per segment before making major decisions.

---

## 3. Data Quality & Validation

### Quality Checks Performed

✅ **Completeness check:** All 10 tools have data across all categories
✅ **Consistency check:** Data from multiple sources align (e.g., pricing on official page vs. G2 product listing)
✅ **Reasonableness check:** Outliers flagged and investigated (e.g., Grok pricing @$168 = X Premium bundle)
✅ **Currency check:** All data marked with collection date (June 2026)
✅ **Source documentation:** Every metric traceable to source

### Known Data Gaps

- **Churn rates:** Not publicly available; recommend customer interviews
- **CAC/LTV:** Not disclosed; would strengthen B2B analysis
- **Actual usage metrics:** "Hours saved" are estimates, not measured; need longitudinal studies
- **Retention cohorts:** Would clarify product stickiness by segment
- **Feature release cadence:** How often do these tools iterate? Affects value over time

---

## 4. Limitations & Caveats

### 1. Sample Bias
**G2 reviews skew toward:**
- B2B/enterprise users (over-represents enterprise satisfaction)
- Early adopters (under-represents mainstream users)
- Motivated reviewers (positive or very negative users more likely to write)

**Impact:** Consumer tool satisfaction may be underrated; enterprise satisfaction may be overrated.

### 2. Point-in-Time Analysis
**Data collected June 2026, but:**
- Pricing changes monthly
- Feature releases are continuous
- Customer reviews accumulate (sample size grows)
- Competitive positioning shifts

**Recommendation:** Refresh data quarterly for ongoing decision-making.

### 3. ROI Assumptions
**Hours saved estimates are:**
- Directional (not precise)
- Based on published claims (not independent measurement)
- Vary hugely by use case (solo dev vs. data scientist vs. writer)
- Assume 100% utilization (real-world lower)

**Implication:** ROI multiples should be treated as "order of magnitude" not "precise predictions."

### 4. Feature Scoring Subjectivity
**What "5" means can vary:**
- Code generation: Is it "5" if it works 80% of the time? 95%?
- Long context: Is 200K tokens "5" or does it need 1M+?

**Mitigation:** Published scoring criteria, but recommend third-party audit before major decisions.

---

## 5. Methodology for Strategic Recommendations

### Opportunity Sizing Framework

For each identified gap, I estimated TAM (Total Addressable Market):

**Example: Vertical AI for Healthcare**
1. US healthcare market size: $4.5T annually
2. AI tools adoption rate: ~10-15% (estimated)
3. Serviceable addressable market (SAM): $450-675B
4. If 1% of SAM pays for vertical AI tool: $4.5-6.75B TAM

**Confidence:** LOW-MEDIUM (estimates based on sector research, not primary data)
**Recommendation:** Validate with TAM/SAM/SOM analysis using bottom-up methodology (customer research).

### Competitive Moat Analysis

For each recommendation, I evaluated:
- **Defensibility:** Can a larger player easily replicate?
- **First-mover advantage:** Is there network effect or switching cost?
- **Vertical integration:** Does control of data/models matter?

**Example: Vertical AI has HIGH defensibility because:**
- Regulatory compliance = high switching cost
- Domain knowledge = hard to replicate quickly
- Customer lock-in = enterprise contracts are multi-year

---

## 6. How to Update This Analysis

### Monthly Refresh (30 min)
- Update pricing from official pages
- Collect latest G2 ratings (new reviews accumulate)
- Note major feature releases

### Quarterly Deep-Dive (4 hours)
- Redo feature matrix (capabilities shift)
- Customer interviews (5-10 per segment)
- Update ROI assumptions based on new data

### Annual Review (1-2 days)
- Complete re-analysis with new tools added
- Competitive landscape reassessment
- Strategic recommendations refresh

---

## 7. Data Files & Calculations

### Excel File: `AI_Tools_Market_Analysis.xlsx`

**Sheets:**
1. **Tool Overview** — Basic info on all 10 tools
2. **Pricing Comparison** — Price tiers and annual discounts
3. **Features Matrix** — 12 capabilities rated 0-5
4. **Review Data** — G2 ratings and review counts
5. **Segment Analysis Setup** — ROI model with editable assumptions
6. **Analysis Dashboard** — Calculated metrics and rankings
7. **Data Dictionary** — Definitions of all metrics

**Key formulas:**
- Annual spend = Monthly spend × 12
- Hours saved value = Hours/week × Hourly rate × 52
- ROI multiple = Annual value ÷ Annual cost
- Payback period = 12 ÷ ROI multiple

**How to modify:**
- Change BLUE cells (inputs)
- All BLACK cells (formulas) update automatically
- Download the file and experiment with assumptions

---

## 8. Confidence Levels Summary

| Data Category | Confidence | Source | Refresh |
|---------------|-----------|--------|---------|
| Pricing | HIGH | Official pages | Monthly |
| Features | MEDIUM-HIGH | Product docs + demos | Quarterly |
| G2 Ratings | HIGH | G2.com | Monthly |
| ROI Assumptions | MEDIUM | Industry benchmarks | Quarterly |
| Market Gaps | MEDIUM | Trend analysis | Quarterly |
| Recommendations | MEDIUM | Financial models | Annually |

---

## 9. Next Steps for Enhancement

To strengthen this analysis:

1. **Customer interviews** (1-2 weeks)
   - 5-10 interviews per segment
   - Validate hours-saved assumptions
   - Understand buying criteria beyond features/price

2. **Competitive war-gaming** (3-4 days)
   - How would ChatGPT respond to Model Aggregator threat?
   - What would Claude do to defend market share?
   - What partnerships matter?

3. **Financial modeling** (1 week)
   - Build detailed P&L models for each recommendation
   - Unit economics (CAC, LTV, margin)
   - Scenario planning (bull/base/bear cases)

4. **Market sizing validation** (1-2 weeks)
   - Bottom-up TAM analysis (vs. top-down estimates)
   - Competitor benchmarking (pricing by segment)
   - Willingness-to-pay research

---

## 10. Contact & Questions

**Questions about methodology?**
- Check `FAQ.md` for common questions
- Review the Excel file (all formulas are documented)
- Reach out with specific data validation concerns

**Found an error?**
- Data errors: Please verify with original source, then flag
- Methodology concerns: Happy to discuss tradeoffs
- Recommendation critiques: Strongest if backed by alternative data

---

**Last updated:** June 2026
**Methodology version:** 1.0
**Status:** Complete, ready for review
