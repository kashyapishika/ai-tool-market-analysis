# Frequently Asked Questions

## Data & Methodology

### Q: How confident are you in these numbers?

**A:** Different confidence levels for different data categories:

- **Pricing:** HIGH (official sources, current as of June 2026)
- **Features:** MEDIUM-HIGH (some subjective rating, recommend third-party audit)
- **G2 ratings:** HIGH (17K+ verified reviews = strong sample)
- **ROI assumptions:** MEDIUM (directional, not predictive)

**The key:** Pricing and satisfaction are well-sourced. ROI multiples need customer validation.

---

### Q: How were the 10 tools selected?

**A:** Criteria:
1. Market adoption (top 10 by user base or funding)
2. Diversity of use cases (code, writing, research, images)
3. Mix of stages (mature + emerging)
4. Geographic/organizational mix

This gives a representative sample, though smaller tools (Open Assistant, Llama, etc.) exist but are harder to evaluate with public data.

---

### Q: Why is the data from June 2026?

**A:** That's when I conducted the analysis. Pricing, customer satisfaction, and features change continuously. Recommend refreshing:
- Monthly: Pricing + review counts
- Quarterly: Features + ROI assumptions
- Annually: Full re-analysis with new entrants

---

### Q: Can I use your ROI calculator for my company?

**A:** Yes, but customize the assumptions:
1. Download the Excel file
2. Change the BLUE cells in "Segment Analysis Setup":
   - Hours/week saved (your estimate, not mine)
   - Hourly rates (your employee costs)
3. Watch the ROI multiples update automatically

**Important:** These are estimates. Validate with your own data.

---

### Q: What data is missing?

**A:** Good question. These would strengthen the analysis:
- Churn rates (which tools do customers stick with?)
- CAC/LTV (actual unit economics)
- Real usage metrics (not estimated hours saved)
- Retention cohorts (stickiness by segment)
- Feature release velocity (how fast do they iterate?)

Recommend collecting via customer interviews.

---

## Findings & Interpretation

### Q: Why is Claude rated highest but ChatGPT is more popular?

**A:** Classic quality vs. adoption paradox. Claude wins on:
- Customer support quality
- Code generation capability
- Long-context window
- Safety/alignment focus

ChatGPT wins on:
- Brand recognition (launched first)
- Broader integrations
- Consumer ease-of-use
- Network effects

**Lesson:** Good product ≠ market leadership. Positioning + GTM matter equally.

---

### Q: Are you saying I should use Claude instead of ChatGPT?

**A:** Depends on your use case:
- **For code analysis/long documents:** Claude
- **For quick creative writing:** ChatGPT
- **For web search:** Perplexity
- **For code completion:** GitHub Copilot

Better strategy: Use multiple tools, or wait for the multi-model aggregator.

---

### Q: Is the SMB ROI 54x realistic?

**A:** It's plausible but aggressive. Assumptions:
- Solo developer saves 5 hours/week (coding, debugging, writing)
- At $50/hour rate
- Spending $240/year on tools
- 54x return = saving $13K/year

**Reality check:**
- Some developers save more (50%+ of time)
- Some save less (already efficient)
- Hours saved assumption should be validated in interviews

**Recommendation:** Treat as directional (ROI is very positive) not prescriptive (exactly 54x).

---

## Strategic Recommendations

### Q: Why rank Model Aggregator #3 if it's fastest to revenue?

**A:** Risk-adjusted return:
- **Aggregator:** Fast revenue but low defensibility (OpenAI could build overnight)
- **Healthcare:** Slower revenue but high defensibility (regulatory moat)
- **Research:** Fast traction + defensibility + acquisition potential

My ranking prioritizes long-term value over short-term revenue.

---

### Q: Which opportunity would you pick?

**A:** If I had to pick ONE:

**For rapid revenue:** Multi-Model Aggregator
**For sustainable business:** Vertical AI (Healthcare)
**For fastest learning:** Research Assistant

The "best" choice depends on your team's strengths, capital, and risk tolerance.

---

### Q: How realistic are the 3-year financial projections?

**A:** Directional, not prophetic. Actual results depend on:
- Execution quality (how well you build/sell)
- Competitive response (will incumbents copy?)
- Market adoption rate (is timing right?)
- Your burn rate (do you have runway?)

These are "if everything goes well" scenarios, not base cases. Recommend 60% sensitivity analysis (what if adoption is 40% lower?).

---

### Q: Can you help me evaluate which recommendation to pick?

**A:** Framework I'd use:

**Step 1:** Honest assessment of your team
- Healthcare AI? → Build Vertical AI
- Enterprise sales? → Build Aggregator
- Consumer product? → Build Research Assistant

**Step 2:** Capital assessment
- Bootstrapped? → Aggregator (fastest cash)
- Well-funded? → Healthcare (longer runway acceptable)

**Step 3:** Market timing
- Is the market right NOW? (probably yes for research, yes for aggregator, maybe for healthcare)

Happy to discuss if you share more context.

---

## Using This for Interviews

### Q: Can I present this analysis in interviews?

**A:** Absolutely. This is designed as a portfolio project. Tips:
1. Download the Excel file and explore it (know your data)
2. Practice the 15-minute pitch (in pitch-script.txt)
3. Be ready to defend your assumptions
4. Acknowledge limitations (don't oversell certainty)
5. Show thinking process, not just conclusions

---

### Q: What if interviewers ask "What would you do differently?"

**A:** Good answers:
- "I'd conduct 10 customer interviews per segment to validate ROI assumptions"
- "I'd do pricing elasticity analysis (what if we charge 30% more?)"
- "I'd build detailed financial models (CAC, LTV, churn assumptions)"
- "I'd competitive war-game (what would OpenAI do if we launched Model Aggregator?)"

Shows you understand what you don't know.

---

### Q: How do I customize this for different roles?

**A:** Role-specific emphasis:

**For Product Manager:**
- Lead with market gaps + opportunities
- Emphasize competitive positioning
- Show understanding of go-to-market strategy

**For Business Analyst:**
- Lead with methodology + data sources
- Show ROI modeling rigor
- Emphasize segmentation + differentiation

**For Data Analyst:**
- Lead with data collection process
- Show statistical approach
- Highlight visualization/communication

**For Investor Pitch:**
- Lead with TAM + financial models
- Show defensibility + competitive moat
- Close with why now + team fit

---

## Technical Questions

### Q: Can I fork/modify this analysis?

**A:** Yes. MIT licensed. You can:
- Modify recommendations
- Update data with new tools
- Extend to other markets (EU, APAC)
- Use methodology for different analyses

Please credit the original (link back to repo).

---

### Q: How do I update the Excel file?

**A:** 
1. Open: `data/AI_Tools_Market_Analysis.xlsx`
2. Find BLUE cells (input assumptions)
3. Change the values
4. All BLACK cells (formulas) update automatically
5. No coding needed

---

### Q: Can I add more tools to the analysis?

**A:** Yes. The Excel file is structured for this:
1. Add row to "Tool Overview" sheet
2. Add columns to "Pricing Comparison"
3. Add columns to "Features Matrix"
4. Add row to "Review Data"
5. Update "Analysis Dashboard" formulas

Recommend documenting sources in "Data Dictionary" sheet.

---

## General

### Q: What's the best way to learn from this project?

**A:** 
1. Read README.md (overview)
2. Skim METHODOLOGY.md (understand the approach)
3. Open Excel file, explore each sheet
4. Read FINDINGS.md (detailed analysis)
5. Review RECOMMENDATIONS.md (strategic thinking)
6. Practice pitch-script.txt (delivery)

Then ask yourself: "What would I do differently?" That's where learning happens.

---

### Q: Can I hire you for similar analyses?

**A:** This is a portfolio project meant for learning/interviews. If you need market analysis:
- Hire a consulting firm (McKinsey, BCG, Bain)
- Use market research (Gartner, IDC, Forrester)
- Conduct your own analysis (following this methodology)

---

### Q: Found an error. How do I report it?

**A:** 
- Data error? Check METHODOLOGY.md source list, verify with original source
- Recommendation error? Propose alternative with reasoning
- Methodology question? Happy to discuss tradeoffs

---

**Last updated:** June 2026  
**Questions?** Fork the repo and suggest improvements.
